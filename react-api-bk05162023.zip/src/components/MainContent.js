import React from "react";

const MainContent = () => {
    return (
        <>
            <section id="prediction">
                <div className="container" data-aos="fade-up">
                    <div id="game_location">

                    </div>
                </div>
            </section>
        </>
    )
}

export default MainContent;