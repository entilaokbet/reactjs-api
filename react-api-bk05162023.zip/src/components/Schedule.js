import React from "react";

import Header from "./Header";
const Schedule = () => {
    return (
        <>
            <Header />
            <div className="container">
                Schedule
            </div>
        </>
    )
}

export default Schedule;