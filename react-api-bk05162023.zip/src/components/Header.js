import React from "react";
import headerBanner from "../assets/img/banner.webp";
import fb from "../assets/img/fb.svg";
import tg from "../assets/img/tg.svg";
const Header = () => {
    return (
        <>
            <header className="container">
                <img src={headerBanner} className="App-logo" alt="OKBET" />
            </header>
            <div id="floating-icons">
                <ul>
                    <li>
                        <img
                            src={tg}
                            width="48px"
                            height="48px"
                            onClick="randomTG();"
                            alt="telegram"
                        />
                    </li>
                    <li>
                        <img
                            src={fb}
                            width="48px"
                            height="48px"
                            onClick="randomSite();"
                            alt="facebook"
                        />
                    </li>
                </ul>
            </div>
        </>
    )
}

export default Header;