import React from "react";
import Header from "./Header";

const History = () => {
    return (
        <>
            <Header />
            <div className="container">
                History
            </div>
        </>
    )
}

export default History;