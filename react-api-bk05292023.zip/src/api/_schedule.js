import React from 'react';
//import React, { setState } from 'react';
// import axios from 'axios';

// export default {
//     getData: () =>
//         axios({
//             method: 'POST',
//             //mode: 'cors',
//             url: 'https://react.okbetscore.ph/response.json',
//             headers: {
//                 'Content-Type': 'application/json',
//                 'Access-Control-Allow-Origin': '*',
//                 //'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE,PATCH,OPTIONS',
//                 'Access-Control-Allow-Methods': 'POST',
//             },
//             body: JSON.stringify({ "endTime": "", "startTime": "", "leagueIdList": [], "matchIdList": [], "gameType": "BK", "matchType": "LGPC", "playCateMenuCode": "LGPC" }),
//             //'params': {
//             //    'search':'parameter',
//             //},
//         })
// }

// export default {
//     api: () => {
//         // GET request using fetch with error handling
//         fetch('https://react.okbetscore.ph/response.json')
//             .then(async response => {
//                 const data = await response.json();

//                 // check for error response
//                 if (!response.ok) {
//                     // get error message from body or default to response statusText
//                     const error = (data && data.message) || response.statusText;
//                     return Promise.reject(error);
//                 }

//                 this.setState({ totalReactPackages: data.total })
//             })
//             .catch(error => {
//                 this.setState({ errorMessage: error.toString() });
//                 console.error('There was an error!', error);
//             });
//     }
// }


export default {
    api: () => {
        // GET request using fetch with set headers
        const headers = { 'Content-Type': 'application/json' }
        fetch('https://react.okbetscore.ph/response.json', { headers })
            .then(response => response.json())
            .then(data => this.setState({ totalReactPackages: data.msg }));
    }
}
