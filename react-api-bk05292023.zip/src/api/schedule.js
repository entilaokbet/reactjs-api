import React from 'react';

export default {
    api: () => {
        // GET request using fetch with set headers
        const headers = { 'Content-Type': 'application/json' }
        fetch('https://react.okbetscore.ph/response.json', { headers })
            .then(response => response.json())
            .then(data => this.setState({ totalReactPackages: data.msg }));
    }
}
