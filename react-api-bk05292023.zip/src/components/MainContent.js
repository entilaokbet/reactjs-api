import React, { useEffect, useState } from 'react';
import { Accordion } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
//import Accordion from 'react-bootstrap/Accordion';
import ObjectRand from '../obj/random-score';

//import api from '../api/schedule';
//import { ActivityIndicator, FlatList, Text, View } from 'react-native';

//import APIScheduleProjection from "./APIScheduleProjection";
//const baseURL = "https://www.okbet.com/api/front/match/odds/simple/list";

export default function MainContent() {

    const [mainLoop, setDataLoop] = useState([]);
    const [data, setData] = useState([]);
    const [ArrleagueOdds, setDataleagueOdds] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [dataMatch, setMatchData] = useState([]);

    const [flags, setDataFlagiCons] = useState([]);
    //const collectData = Array(data);

    //console.log(Arr);

    /* StartTime */
    const getStartTimeDate = new Intl.DateTimeFormat('en-US', { year: 'numeric', month: '2-digit', day: '2-digit' }).format(dataMatch.startTime);
    const getStartTimeTime = new Intl.DateTimeFormat('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(dataMatch.startTime);
    /* EndTime */

    const gameIcons = <svg className="svg-wrap" viewBox="" xmlns="http://www.w3.org/2000/svg" dangerouslySetInnerHTML={{ __html: data.categoryIcon }}></svg>;

    {
        (function (displayFlag, i, len) {
            while (++i <= len) {
                const items = mainLoop.leagueOdds[0].league;
                //console.log(items.categoryIcon);
                displayFlag.push(<div className="show score-board" key={i}>{items}</div>)
            }
            return displayFlag
            //setDataFlagiCons(displayFlag);
        })([], 0, ArrleagueOdds)
    }

    useEffect(() => {
        fetch('http://localhost:8080')
            .then(response => response.json())
            .then((usefulData) => {
                console.log(usefulData.t);
                //const leagueOddsCount = usefulData.t.leagueOdds.length;
                //console.log(leagueOddsCount);

                setDataLoop(usefulData.t);

                setData(usefulData.t.leagueOdds[0].league);
                setDataleagueOdds(usefulData.t.leagueOdds.length);
                setMatchData(usefulData.t.leagueOdds[0].matchOdds[0].matchInfo);

                setLoading(false);
            })
            .catch((e) => {
                console.error(`An error occurred: ${e}`)
            });
    }, []);

    //const timestamp = Date.now(); // This would be the timestamp you want to format
    //console.log(new Intl.DateTimeFormat('en-US', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(dataMatch.startTime));

    return (
        <>
            <section id="prediction">
                <div className="container" data-aos="fade-up">
                    <div id="game_location" className="">
                        {loading && <p>Loading...</p>}
                        {!loading && <p>Fetched data</p>}
                        <Accordion defaultActiveKey={data.id}>

                            {(function (Arr, i, len) {
                                while (++i < len) {
                                    const items = mainLoop.leagueOdds[i].league;
                                    const miniFlags = mainLoop.leagueOdds[i].league.categoryIcon;
                                    const svgFlags = <svg className="svg-wrap" xmlns="http://www.w3.org/2000/svg" dangerouslySetInnerHTML={{ __html: miniFlags }}></svg>;

                                    const gameName = mainLoop.leagueOdds[i].league.name;
                                    const NumMatchOdds = mainLoop.leagueOdds[i].matchOdds.length;

                                    //console.log(i);
                                    Arr.push(<Accordion.Item eventKey={i}>
                                        <Accordion.Header>{svgFlags} {gameName} #{i}</Accordion.Header>

                                        {(function (ArrBody, o, matchinfoLen) {
                                            while (++o < matchinfoLen) {
                                                console.log('leng: sd' + ArrBody);
                                                const gamePlay = mainLoop.leagueOdds[i].matchOdds[0].matchInfo;

                                                ArrBody.push(<Accordion.Body eventKey={o}>
                                                    ASD #{o}
                                                </Accordion.Body>)
                                            }
                                            return ArrBody;
                                        })([], 0, NumMatchOdds)}

                                    </Accordion.Item>)
                                }
                                return Arr;
                            })([], 0, ArrleagueOdds)}
                        </Accordion>

                    </div>
                </div>
            </section>
        </>
    )
}

